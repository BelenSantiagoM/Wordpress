<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '-rBC2XU?D7>vZ#]{h sl{sqHA_?2ELV8?Y~wv_0(m=_N*Eg#p4^5*w_5oCw<#NZ^' );
define( 'SECURE_AUTH_KEY',  'p~D|8@[mzl$ xVAwaHmt|1V&c8WW^bDs BwyG&2l3yNsUkQrzlSn4p_nMn2[K@zk' );
define( 'LOGGED_IN_KEY',    's1E;A9::-v<_VGJpI9cnv0`N)~f-@Wx3xo&XN|??wzfCGzx9+H%kX1@xT+5]E6Z1' );
define( 'NONCE_KEY',        'u;mgvI+!Nu_/x#j6O1Mc|N24`X&,kT/LT- `g,n]2$deM!NuRxI@_NL>y<t.7P&K' );
define( 'AUTH_SALT',        'p9Q=T(Y{q)1L_e9THkfsp3L-2naIG/m3ICeQ~M_4!~,QJfEETxd888lzH,@WP05P' );
define( 'SECURE_AUTH_SALT', '9Kf[by{S)i4VaB 8+/iXV-py0v:=:ijrr3UvwTAs*$0kB8v2bH$(A31f0hS6Bqc(' );
define( 'LOGGED_IN_SALT',   'W> OMW]ZG/yBu+7Y_3@Wq58(6Emq8hj?F-6/}TtM4%8ewge`[4|t./M^Sv=({#<Q' );
define( 'NONCE_SALT',       'OD7#h#@7sQ/VZ02 `3PFTGUV][RhZ:a0fQLHL`dutt?<cZBybb=D;HrS[q,-xP}&' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
